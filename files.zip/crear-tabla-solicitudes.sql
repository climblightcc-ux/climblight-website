create table solicitudes_creador (
  id bigint generated always as identity primary key,
  creator_id bigint,
  creator_nombre text,
  marca text,
  contacto text,
  whatsapp text,
  presupuesto text,
  mensaje text,
  status text default 'nuevo',
  fecha timestamptz default now()
);

alter table solicitudes_creador disable row level security;
